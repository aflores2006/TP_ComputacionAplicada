# Validación de la opción de ayuda o cantidad incorrecta de argumentos
if [[ "$1" == "-help" || "$#" -ne 2 ]]; then
    echo "Uso: $(basename $0) <directorio_origen> <directorio_destino>"
    echo "Ejemplo: $0 /etc /backup_dir"
    exit 1
fi

# Definición de variables
ORIGEN="$1"
DESTINO="$2"
HOY=$(date +%Y%m%d)

# Verificación de existencia del directorio de origen
if [[ -d "$ORIGEN" ]]; then
    echo "El directorio de origen $ORIGEN existe y está montado."

    # Verificación de existencia del directorio de destino
    if [[ -d "$DESTINO" ]]; then
        echo "El directorio de destino $DESTINO existe y está montado."

        # Nombre del archivo backup
        NOMBRE_BACKUP="$(basename "$ORIGEN")_bkp_${HOY}.tar.gz"

        # Creación del backup
        if tar -czpf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"; then
            echo "Backup de $ORIGEN completado correctamente en $DESTINO/$NOMBRE_BACKUP." >> /var/log/bkpTP.log
            echo "Backup finalizado correctamente."
        else
            echo "Error al crear el backup de $ORIGEN, el día $HOY" >> /var/log/bkpTP.log
        fi
    else
        echo "Error: El directorio de destino $DESTINO no existe o no está montado."
        echo "Error al crear el backup, el día $HOY, el directorio de destino $DESTINO no existe o no está montado." >> /var/log/bkpTP.log
    fi
else
    echo "Error: El directorio de origen $ORIGEN no existe o no está montado."
    echo "Error al crear el backup, el día $HOY, el directorio de origen $ORIGEN no existe o no está montado." >> /var/log/bkpTP.log
fi
